import { Component } from '@angular/core';

@Component({
  selector: 'app-simple-example-if',
  templateUrl: './simple-example-if.component.html',
  styleUrls: ['./simple-example-if.component.css']
})
export class SimpleExampleIfComponent {
showMe:boolean;

 ShowStatus() {
  alert(this.showMe);
}
}
