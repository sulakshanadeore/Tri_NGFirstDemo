import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SimpleExampleIfComponent } from './simple-example-if.component';

describe('SimpleExampleIfComponent', () => {
  let component: SimpleExampleIfComponent;
  let fixture: ComponentFixture<SimpleExampleIfComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [SimpleExampleIfComponent]
    });
    fixture = TestBed.createComponent(SimpleExampleIfComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
