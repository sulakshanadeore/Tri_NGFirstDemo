import { Skills } from "./skills";

export class Employee{
empid:number;
empname:string;
empdeptno:number;

skills:Skills[];

}

