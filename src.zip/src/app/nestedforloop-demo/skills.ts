export class Skills
{
skillid:number;
skillName:string;


}