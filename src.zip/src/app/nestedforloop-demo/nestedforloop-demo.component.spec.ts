import { ComponentFixture, TestBed } from '@angular/core/testing';

import { NestedforloopDemoComponent } from './nestedforloop-demo.component';

describe('NestedforloopDemoComponent', () => {
  let component: NestedforloopDemoComponent;
  let fixture: ComponentFixture<NestedforloopDemoComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [NestedforloopDemoComponent]
    });
    fixture = TestBed.createComponent(NestedforloopDemoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
