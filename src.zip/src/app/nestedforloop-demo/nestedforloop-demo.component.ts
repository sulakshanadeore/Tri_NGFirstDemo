import { Component } from '@angular/core';
import { Employee } from './employee';

@Component({
  selector: 'app-nestedforloop-demo',
  templateUrl: './nestedforloop-demo.component.html',
  styleUrls: ['./nestedforloop-demo.component.css']
})
export class NestedforloopDemoComponent {
emp:Employee[]=[
{empid:1,empname:"Arjun",empdeptno:10,skills:[{skillid:1,skillName:"C#"},{skillid:2,skillName:"HTML"},{skillid:3,skillName:"TS"}]},
{empid:2,empname:"Kamal",empdeptno:10,skills:[{skillid:1,skillName:"Asp"},{skillid:2,skillName:"HTML"}]},
{empid:3,empname:"Simran",empdeptno:20,skills:[{skillid:1,skillName:"MVC"},{skillid:2,skillName:"HTML"},{skillid:3,skillName:"TS"},{skillid:4,skillName:"WCF"}]},
{empid:4,empname:"Sima",empdeptno:20,skills:[{skillid:1,skillName:"WCF"},{skillid:2,skillName:"WPF"},{skillid:3,skillName:"WF"}]}

];





}
