import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DoMathsComponent } from './do-maths.component';

describe('DoMathsComponent', () => {
  let component: DoMathsComponent;
  let fixture: ComponentFixture<DoMathsComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [DoMathsComponent]
    });
    fixture = TestBed.createComponent(DoMathsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
