import { ComponentFixture, TestBed } from '@angular/core/testing';

import { BindingStyleClassDemoComponent } from './binding-style-class-demo.component';

describe('BindingStyleClassDemoComponent', () => {
  let component: BindingStyleClassDemoComponent;
  let fixture: ComponentFixture<BindingStyleClassDemoComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [BindingStyleClassDemoComponent]
    });
    fixture = TestBed.createComponent(BindingStyleClassDemoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
