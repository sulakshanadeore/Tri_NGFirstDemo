import { Component } from '@angular/core';

@Component({
  selector: 'app-binding-style-class-demo',
  templateUrl: './binding-style-class-demo.component.html',
  styleUrls: ['./binding-style-class-demo.component.css']
})
export class BindingStyleClassDemoComponent {

  redClass="c1Red";


  isRedApplied=!true;

  public classObj = {  
    red : true,  
    bgYellow : false,  
    italic: false,
    bold:true,
    bckgrd:true
  }; 

  SizeOfTheFont=10;


  IsBold=true;
  IsItalic=true;
  fSize=20;
  fColor="Magenta";
  tCenter="Center";

  MultipleInlineStyle() {  
    let myStyleClass = {  
      'font-weight': this.IsBold ? 'bold' : 'normal',  
      'font-style': this.IsItalic ? 'italic' : 'normal',  
      'font-size.px': this.fSize,  
      'color': this.fColor,  
      'text-align': this.tCenter  
    };  
    return myStyleClass;  
  }




}
