import { Categories } from "./Categories";

 export class Products
{
prodid:number;
prodname:string;
prodprice:number;
categories:Categories;

}