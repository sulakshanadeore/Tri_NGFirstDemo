import { Component } from '@angular/core';
import { Products } from './Products';


@Component({
  selector: 'app-directive-demo',
  templateUrl: './directive-demo.component.html',
  styleUrls: ['./directive-demo.component.css']
})
export class DirectiveDemoComponent {

// products:Products[]=[
//   {prodid:1,prodname:"Mobiles",prodprice:30000},
//   {prodid:2,prodname:"Tablets",prodprice:30000},
//   {prodid:3,prodname:"Charger",prodprice:1000},
//   {prodid:4,prodname:"FireStick",prodprice:10000},
//   {prodid:5,prodname:"TV",prodprice:50000},

// ];


prodCategories:Products[]=[
{prodid:1,prodname:"tea",prodprice:10,categories:{catid:101,catname:"beverages"}},
{prodid:2,prodname:"bru coffee",prodprice:10,categories:{catid:101,catname:"beverages"}},
{prodid:3,prodname:"bournvita",prodprice:10,categories:{catid:101,catname:"beverages"}},
{prodid:4,prodname:"snacks",prodprice:10,categories:{catid:102,catname:"Tiny snacks"}},
{prodid:5,prodname:"coffee",prodprice:10,categories:{catid:101,catname:"beverages"}}

];






showButton=true;

showContentInDiv=false;

empJoiningStatus=false;




fun1():boolean
{

  return false;
}


}
