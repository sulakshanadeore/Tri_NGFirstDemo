export class Categories
{
catid:number;
catname:string;


}